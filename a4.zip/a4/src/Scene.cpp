#include "Scene.hpp"

bool
Scene::load(string const & filename, Material const & m)
{
  material = m;
  OBJParser parser;
  bool didParse = parser.parseOBJ(filename, &myMesh);
  if (!didParse)
  {
    cerr << "Since we couldnt parse the OBJ file, we will now quit" << endl;
    exit(1);
  }

  // TODO: Replace these lines with more of your own code to process the loaded scene if necessary.
  // TODO: Hint - texture maps are only on the CPU at this point.

  return didParse;
}

bool
Scene::draw()
{
  SaveGLState save_gl_state;  // will restore state upon destruction

  // Load the shader if it hasn't been loaded yet
  if (!shader.isLoaded())
    if (!shader.load("vert.glsl", "frag.glsl"))
      return false;

  // Use the shader
  shader.enable();

  // TODO: Replace these lines with your own code to draw the loaded scene

  //SOME SAMPLE CODE TO GET YOU GOING:
  // for (size_t fid = 0; fid < myMesh.faces.size(); ++fid)
  // {
  //   OBJFace* f = myMesh.faces[fid];
  //   glBegin(GL_POLYGON);
  //   for (size_t vi = 0; vi < f->v.size(); ++vi)
  //   {
  //     OBJVertex const & vertex = myMesh.vertices[f->v[vi]];
  //   }
  //   glEnd();
  // }

  // Don't replace this line!
  return true;
}
