#include "Global.hpp"

// Define static members
Camera  Global::camera(90, 1, 100000);
Scene   Global::scene;
